/* ===================================================================
   CONFIGURATION FIREBASE — projet "celinelaruelle"
   -------------------------------------------------------------------
   1) Va sur https://console.firebase.google.com
   2) Crée un projet nommé par exemple "celinelaruelle"
   3) Active Authentication > Sign-in method > Email/Password
   4) Active Firestore Database (mode production)
   5) Dans "Paramètres du projet > Général > Vos applications",
      crée une application Web et colle ici les valeurs affichées.
   =================================================================== */

const firebaseConfig = {
  apiKey: "COLLER_ICI_API_KEY",
  authDomain: "COLLER_ICI.firebaseapp.com",
  projectId: "COLLER_ICI_PROJECT_ID",
  storageBucket: "COLLER_ICI.appspot.com",
  messagingSenderId: "COLLER_ICI",
  appId: "COLLER_ICI_APP_ID"
};

// Référence projet — reprise dans les règles Firestore (voir firestore.rules)
const PROJECT_REF = "celinelaruelle";

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

/* Domaine fictif utilisé pour générer un email technique à partir d'un
   simple identifiant (les membres/admin se connectent en "identifiant + mot
   de passe", pas en email). */
const AUTH_DOMAIN_SUFFIX = "@celinelaruelle.local";

function usernameToEmail(username){
  return username.trim().toLowerCase().replace(/\s+/g,'') + AUTH_DOMAIN_SUFFIX;
}
